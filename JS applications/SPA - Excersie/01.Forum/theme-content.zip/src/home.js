import { showDetails } from "./details.js"

export function homeView(){
    const homeEl = document.querySelector('nav ul li a')
    homeEl.addEventListener('click', (e) =>loadHome(e))
    
}

export async function loadHome(e){
const dataValues = await getAllPosts()
showPosts(dataValues)

}

export async function getAllPosts(){
    const response = await fetch('http://localhost:3030/jsonstore/collections/myboard/posts')
    const data = await response.json()
    const dataValues = Object.values(data)

return dataValues
}

function showPosts(dataValues){

    const topicEL = document.querySelector('.topic-title')

    topicEL.innerHTML = ''
    for (const post of dataValues) {
        
        const date = localStorage.getItem('postDate') || new Date().toLocaleString('en-GB', { hour12: false });
        
        const topicContainer = document.createElement('div');
        topicContainer.classList.add('topic-container')
        topicContainer.id = `${post._id}`
        topicContainer.innerHTML = `
        <div class="topic-name-wrapper">
        <div class="topic-name">
            <a href="#" class="normal">
                <h2>${post.title}</h2>
            </a>
            <div class="columns">
                <div>
                    <p>Date: <time>${date}</time></p>
                    <div class="nick-name">
                        <p>Username: <span>${post.username}</span></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
        `
        topicEL.appendChild(topicContainer)
        topicContainer.querySelector('a').addEventListener('click',showDetails)
    }

}

export async function reloadOnPost(){
    const dataValues = await getAllPosts()
    const topicEL = document.querySelector('.topic-title')
    topicEL.innerHTML = ''
    showPosts(dataValues)
}