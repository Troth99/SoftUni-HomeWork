import { reloadOnPost } from "./home.js"
const postUrl = 'http://localhost:3030/jsonstore/collections/myboard/posts'

export function creatingTheForm() {
    const formEl = document.querySelector('form')

    const cancelBtn = formEl.querySelector('.cancel');
    const publicBtn = formEl.querySelector('.public')

    cancelBtn.addEventListener('click', (e) => {

        e.preventDefault()
        clearForm()
        return
    })

    formEl.addEventListener('submit', (e) => submitingPost(e))



}

async function submitingPost(e) {
    e.preventDefault()
    const formData = new FormData(e.target)
    const title = formData.get('topicName');
    const userName = formData.get('username')
    const post = formData.get('postText')

    const date = new Date().toLocaleString('en-GB', { hour12: false });

    if (title === '' || userName === '' || post === '') {
        alert('Please fill all inputs')
        return
    }
    const postObj = {
        title,
        username: userName,
        content: post,
        date,
    }
    const response = await fetch(postUrl, {
        method: 'POST',
        headers: {
            'Content-Type': "application/json"
        },
        body: JSON.stringify({title, username: userName, content: post})
    })

    clearForm()
    const postData = await response.json()

    reloadOnPost()

}
function clearForm() {
    const formEl = document.querySelector('form')
    formEl.reset()
}


