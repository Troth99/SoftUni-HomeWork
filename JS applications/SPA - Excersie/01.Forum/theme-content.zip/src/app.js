import { creatingTheForm } from "./createTopic.js"
import { homeView , loadHome} from "./home.js"
import { details } from "./details.js"

export function visibleTopics() {

    creatingTheForm()
    homeView()

    loadHome()

}

visibleTopics()
