import { getAllPosts, loadHome } from "./home.js"

export function details(e) {
    loadHome()
    showDetails(e)
}

const main = document.querySelector('body')

const dataValues = await getAllPosts()

export function showDetails(e) {
    const date = new Date().toLocaleString('en-GB', { hour12: false })
    const topicId = e.currentTarget.parentElement.parentElement.parentElement.id

    const currentPost = dataValues.filter(post => post._id === topicId)

    console.log(currentPost[0].username)
    main.innerHTML = ''

    const contentDiv = document.createElement('div')
    contentDiv.classList.add('comment')
    contentDiv.innerHTML = `
        <div class="header">
        <img src="./static/profile.png" alt="avatar">
        <p><span>${currentPost[0].username}</span> posted on <time>${date}</time></p>
        <p class="post-content">${currentPost[0].content}</p>
    </div>
    `
    main.appendChild(contentDiv)

    // Секция за коментари
    const commentDiv = document.createElement('div')
    commentDiv.classList.add('answer-comment')

    commentDiv.innerHTML = `
        <p><span>currentUser</span> comment:</p>
        <div class="answer">
            <form>
                <textarea name="postText" id="comment" cols="30" rows="10"></textarea>
                <div>
                    <label for="username">Username <span class="red">*</span></label>
                    <input type="text" name="username" id="username">
                </div>
                <button>Post</button>
            </form>
        </div>
    `
    main.appendChild(commentDiv)

    // След изпращането на нов коментар
    commentDiv.addEventListener('submit', (e) => postData(e, topicId))
}

// Функция за обработка на данни при изпращане на коментар
async function postData(e, topicId) {
    e.preventDefault()

    const formData = new FormData(e.target)
    const comment = formData.get('postText')
    const userName = formData.get('username')

    console.log(comment, userName)

    const postObj = {
        text: comment,
        username: userName,
        postId: topicId
    }

    try {
        // Изпращане на коментара към сървъра
        const response = await fetch('http://localhost:3030/jsonstore/collections/myboard/comments', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(postObj)
        })

        const data = await response.json()
        console.log(data)

        // След добавяне на коментара, обновяваме коментарите на страницата
        showComments(topicId)

    } catch (error) {
        console.log('Error:', error)
    }
}

// Функция за показване на коментарите
async function showComments(topicId) {
    const response = await fetch('http://localhost:3030/jsonstore/collections/myboard/comments')
    const commentsData = await response.json()

    // Филтрираме коментарите за даден пост
    const comments = Object.values(commentsData).filter(comment => comment.postId === topicId)

    // Изчистваме старите коментари и добавяме новите

    comments.forEach(comment => {
        const commentDiv = document.createElement('div')
        commentDiv.classList.add('user-comment')
        commentDiv.innerHTML = `
            <p><strong>${comment.username}</strong> commented on <time>${new Date().toLocaleString('en-GB', { hour12: false })}</time></p>
            <div class="post-content">
                <p>${comment.text}</p>
            </div>
        `
        main.appendChild(commentDiv)
    })
}


